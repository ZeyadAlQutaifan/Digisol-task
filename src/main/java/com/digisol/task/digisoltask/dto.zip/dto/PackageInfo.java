package com.digisol.task.digisoltask.dto;

import lombok.Data;

@Data
public class PackageInfo {
    private String brandedDealsIdentifier;
}
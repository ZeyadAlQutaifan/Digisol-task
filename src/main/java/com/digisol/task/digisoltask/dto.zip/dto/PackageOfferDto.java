package com.digisol.task.digisoltask.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class PackageOfferDto {
    private String fromCity;
    private String toCity;
    private String hotelName;
    private double price;
}